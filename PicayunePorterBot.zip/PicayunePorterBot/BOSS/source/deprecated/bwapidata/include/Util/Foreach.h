#pragma once

#define foreach(element, collection) for (element : collection)
